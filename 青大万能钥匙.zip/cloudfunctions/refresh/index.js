// 云函数入口文件
const cloud = require('wx-server-sdk')
const db = cloud.database()
const _ = db.command
// 云函数入口函数
cloud.init({
  env:"classroom-selecr-2flpq2d6edc219a"
})

exports.main = async (event, context) => {
  try {
    return await db.collection('caijing').where({
      state: true
    })
    .update({
      data: {
        state:false
      },
    })
  } catch(e) {
    console.error(e)
  }
}