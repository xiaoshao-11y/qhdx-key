// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"classroom-selecr-2flpq2d6edc219a"
})

// 云函数入口函数
exports.main = async (event, context) => {
  return cloud.database().collection("course_timetable").get({
    success:function(res)
    {
      return res
    }
  })
}