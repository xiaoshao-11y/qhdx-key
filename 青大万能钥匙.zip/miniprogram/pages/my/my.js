// pages/my/my.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  goto4:function()
  {
    wx.navigateTo({
      url:'/pages/next/next',
    })
  },

  onLoad:function(){
    var that=this
  wx.showModal({
    title: '提示',
    content: '您还不是VIP哦',
    success: function (res) {
      if (res.confirm) {   //这里是点击了确定以后
        console.log('用户点击确定')
      } else {     //这里是点击了取消以后
        console.log('用户点击取消')
      }
    }
  })
},

})