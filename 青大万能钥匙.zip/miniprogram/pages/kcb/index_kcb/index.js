//index.js
//获取应用实例
const db=wx.cloud.database()
var app = getApp()
Page({
  data: {
    colorArrays: [ "#85B8CF", "#90C652", "#D8AA5A", "#FC9F9D", "#0A9A84", "#61BC69", "#12AEF3", "#E29AAD"],
    list:[]
  },
  onLoad: function () {
    var that=this
    wx.cloud.callFunction({
      name:"get",
      success:function(res)
      {
        that.setData({
          list:res.result.data
        })
        console.log("res",res)
      }
    })
    // wx.cloud.database().collection('course_timetable')
    // .skip(0)
    // .limit(100).get().then(res => {
    //  // console.log('获取成功', res)
    //  console.log("index:res",res)
    //   this.setData({
    //     list: res.data
    //   })
    // })
  },
  change(){
    wx.navigateTo({
      url: '/pages/kcb/class_kcb/class'
    })
  }

})