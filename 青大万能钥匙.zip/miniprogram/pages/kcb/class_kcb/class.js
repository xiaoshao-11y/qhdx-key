const db=wx.cloud.database()
Page({
  data: {
kcmc_:'0',
skjc_:0,
xqj_:0,
length:0,
xqj_remove_:0,
skjc_remove_:0,
id_remove_:''
  },
  onLoad(options) {
  },
  kcmc(event){
    this.setData({
      kcmc_:event.detail.value
    })
  },
  xqj(event){
    this.setData({
      xqj_:event.detail.value
    })
     // console.log(event.detail.value)
  },
  skjc(event){
    this.setData({
      skjc_:event.detail.value
    })
  },
Add(){
    var that=this
    if(this.data.xqj_>7||this.data.xqj_<1)
    {
      wx.showToast({
        title: '星期错误',
        icon:"none",
        duration:500
      })
    }
    // else 
    // if(this.data.skjc_>10||this.data.skjc_<1)
    // {
    //   wx.showToast({
    //     title: '上课节次应该为奇数或不符合要求',
    //     icon:"none",
    //     duration:700
    //   })
    // }
    else
    {
       if(this.data.skjc_=='1'|this.data.skjc_=='3'|this.data.skjc_=='5'|this.data.skjc_=='7'|this.data.skjc_=='9')
      {
       db.collection('course_timetable').where({
       xqj:this.data.xqj_,
       skjc:this.data.skjc_
     }).skip(0).limit(100).get({
       success:function(res){
         that.setData({
           length:res.data.length
         })
         console.log("success data:length:",that.data.length)
         console.log("res",res)
         console.log("id:",res.data._id)
      }
    })
      if(this.data.length==0)
      {
        console.log("无")
         db.collection('course_timetable').add({
          data:{
         xqj:this.data.xqj_,
         skjc:this.data.skjc_,
         kcmc:this.data.kcmc_
          },
          success:function(){
    wx.showToast({
      title: '添加成功',
      icon:"success",
      duration:700
    })
          }
        })
      }
      else{
        console.log("课程已有")
        wx.showToast({
         title: '该时间点已有课程安排',
         icon:"error",
         duration:700})
     }
     }
      else
    {
      wx.showToast({
        title: '上课节次应该为奇数或不符合要求',
        icon:"none",
        duration:700
      })
    }
    }
  },
  
  xqj_remove(event){
this.setData({
  xqj_remove_:event.detail.value
})
  },
  skjc_remove(event){
    this.setData({
      skjc_remove_:event.detail.value
    })
  },
remove(){
  var that=this
    db.collection("course_timetable").where({
      xqj:this.data.xqj_remove_,
      skjc:this.data.skjc_remove_
    }).skip(0).limit(20).get({
      success:function(res){
        that.setData({
          length:res.data.length,
          id_remove_:res.data[0]._id
        })
      }
    })
    if(this.data.length==0)
  {
    wx.showToast({
    title: '该节点无课程',
    icon:"none",
    duration:700
  })
}
else{db.collection("course_timetable").doc(this.data.id_remove_).remove({
success:function(res){
wx.showToast({
  title: '删除成功',
  icon:"success",
  duration:700
})
this.setData({
  length:length-1
})
console.log("删除成功",res)
}
})
}
},


  skjc_update(event){
    this.setData({
      skjc_update_:event.detail.value
    })
  },
  xqj_update(event){
    this.setData({
      skjc_update_:event.detail.value
    })
  }
})