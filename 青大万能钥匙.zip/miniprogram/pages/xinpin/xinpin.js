// pages/xinpin/xinpin.js
const app = getApp()
Page({
  data:{
    list:[
      {id:1,img:'https://tse3-mm.cn.bing.net/th/id/OIP-C.mW4AfPsz01zF7fX9VtBW-AHaHa?w=202&h=202&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥45',valuea:"四级词汇",valueb:"乱序版",valuec:"英语四级备考2022年12月 新东方英语四级词汇乱序版单词书",date:"2022年6月",phone:"13897363088"},
      {id:2,img:'https://tse4-mm.cn.bing.net/th/id/OIP-C.J8GP4UV1HWHsRMbkpBDgrwHaJQ?w=156&h=195&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥4.5',valuea:"笔记本电脑支架",valueb:"易折叠，稳固 ",valuec:"散热架 折叠升降便携 增高托物架 调节收纳支撑架",date:"2022年08月",phone:"15698742318"},      
      {id:3,img:'https://tse1-mm.cn.bing.net/th/id/OIP-C.A_P40UN8e2ZyNL1jIFJlKQHaE7?w=296&h=197&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥55',valuea:"无线蓝牙耳机",valueb:"四级专用耳机",valuec:"发光 头戴式 重低音耳机 OPPO 华为 苹果安卓通用耳麦",date:"2022年11月",phone:"11566320549"},
      {id:4,img:'https://tse2-mm.cn.bing.net/th/id/OIP-C.awHtSx50Goni3C__35TfngHaLH?w=141&h=212&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥9.98',valuea:"镜子 ins风",valueb:"化妆镜 简约",valuec:"桌面透明 亚克力 宿舍台式风 双面梳妆镜子",date:"2022年07月",phone:"13215694955"},
      {id:5,img:'https://tse3-mm.cn.bing.net/th/id/OIP-C.ZFIKxLT5I8nbMdHlVAQkCQHaHa?w=219&h=219&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥73.98',valuea:"电脑椅 宿舍",valueb:"办公 久坐",valuec:"舒适久坐 靠背椅女生宿舍 升降学习转椅",date:"2022年09月",phone:"11025463699"},
      {id:6,img:'https://tse3-mm.cn.bing.net/th/id/OIP-C.SqsDbYxF4Z8MTfnnLSXgZAHaHa?w=206&h=207&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥10.86',valuea:"情侣 斜挎包",valueb:"日系 百搭",valuec:"ins风潮牌大容量斜挎包韩国休闲尼龙港风机能包情侣工装宝",date:"2022年12月",phone:"16452975800"},  
      {id:7,img:'https://tse3-mm.cn.bing.net/th/id/OIP-C.DiHv5XTgodODbns9IGIobwHaHa?w=196&h=196&c=7&r=0&o=5&dpr=1.1&pid=1.7',money:'￥3.03',valuea:"秋冬 发夹",valueb:"暖冬 大地色系",valuec:"发卡套装侧边一字夹日韩洗脸化妆8cm",date:"2022年11月",phone:"12457869035"}
    ],
    a:"",
},
tiaozhuan:function(event){
  this.setData({a:this.data.list[event.currentTarget.dataset.bid-1]})
  wx.navigateTo({
    url: '../new/new?id='+this.data.a.id+'&img='+this.data.a.img+'&money='+this.data.a.money+'&valuea='+this.data.a.valuea+'&valueb='+this.data.a.valueb+'&valuec='+this.data.a.valuec+'&date='+this.data.a.date+'&phone='+this.data.a.phone,
  })
}
})
