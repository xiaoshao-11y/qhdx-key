function getRandomColor() {
  const rgb = []
  for (let i = 0; i < 3; ++i) {
    let color = Math.floor(Math.random() * 256).toString(16)
    color = color.length === 1 ? '0' + color : color
    rgb.push(color)
  }
  return '#' + rgb.join('')
}

var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  onReady: function (res) {
    this.videoContext = wx.createVideoContext('myVideo')
  },
  danmuList:
      [{
        text: '第 1s 出现的弹幕',
        color: '#ff0000',
        time: 1
      },
      {
        text: '第 3s 出现的弹幕',
        color: '#ff00ff',
        time: 3
      }],
  inputValue: '',
  DanmuTxt:'',
  data: {
    imglist:[] ,
    list: [{
      id: '299371',
      title: '宋浩高等数学',
      videoUrl: 'https://6d6a-mjy-8g65hi37657f862d-1314114575.tcb.qcloud.la/11.mp4'
    },
    {
      id: '299396',
      title: '樊顺厚高等数学',
      videoUrl: 'https://6d6a-mjy-8g65hi37657f862d-1314114575.tcb.qcloud.la/113.mp4'
    },
    {
      id: '299378',
      title: '高数叔高等数学',
      videoUrl: 'https://6d6a-mjy-8g65hi37657f862d-1314114575.tcb.qcloud.la/112.mp4'
    },
   ],
   
  },
  uploadImgView:function(e){
    let _t=this
    wx.chooseImage({
      count: 9, // 最多上传几个 默认9  
      sizeType: ['original','compressed'], // 原图/压缩图  
      sourceType: ['album', 'camera'], // 相册/相机
      success: (res) => {
      // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
      console.log('上传',res)
      // res.tempFilePaths[0]
   
            _t.setData({imglist:res.tempFilePaths})//页面展示用，可以不加
   
      for(let i=0; i<res.tempFilePaths.length; i++ ){
   
        //图片上传云服务
        wx.cloud.uploadFile({
          cloudPath:Date.parse(new Date())+i+'.png',//图片上传时名字会覆盖，所以这边用时间戳和索引值拼的
          //cloudPath:'uploadimage/'+Date.parse(new Date())+index+'.png',//前面加上 文件夹名字/test.png 图片就会上传到指定的文件夹下，否则按上面的会传到根目录下
          filePath:res.tempFilePaths[i], // 文件路径
          success: res => {
          console.log('上传云',res)
          console.log(res.fileID)
          },
          fail: err => {
          console.log('上传云err',err)
          // handle error
          }
        })
   
              //这个可以页面展示或者传给自己接口的后台如果要base64的话 转成base64 可以不加
        //_t.zhuanImage(res.tempFilePaths[i],i)
      }
      }
    });
  },
   
  //将图片转成	base64 用于页面展示		
  zhuanImage:function(imgsrc,index){
    let _t=this
    let list=_t.data.imglist
    wx.getFileSystemManager().readFile({
      filePath:imgsrc, //选择图片返回的相对路径
      encoding: 'base64', //编码格式
      success: res => { //成功的回调
      console.log('111',res)
      // console.log('res---',res)
      let img_flow = 'data:image/png;base64,' + res.data;
      // console.log('img_flow---',img_flow)
      list.push(img_flow)
      _t.setData({imglist:list})
      }
    });
  },


  

  
 


 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.videoCtx=wx.createVideoContext('myVideo')
  },
  playVideo: function (e) {
    this.videoCtx.stop()
    // 停止播放之前正在播放的视频
    this.setData({
      src: e.currentTarget.dataset.url
    })
    // 更新视频地址
    this.videoCtx.play()
    // 播放新的视频
  },

  bindInputBlur: function(e) {
    this.inputValue = e.detail.value
  },
  bindSendDanmu: function () {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    })
  },
  ddd: function(e) {

    wx.navigateTo({
    
    url: '../3/3',
    
    success: function(e) {
    
    console.log(e);
    }
  })
}
    
})