// pages/feedBack/feedBack.js
import {getTimeNow} from '../../utils/index';
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content:'',//文本类容
    commentList:[],
    userInfo:'',
    lookerID:'',
    isLike:false,
    replyContent:[],
    isExtend:false
  },
// 展开或收起评论
  extendOrStow(e){
    this.setData({
      isExtend:!this.data.isExtend
    })
  },
  //评论
  commentDetail(e){
    const index = e.currentTarget.dataset.index
    const reply = e.detail.value
    const time = getTimeNow()
    const {_id,replyContent} = this.data.commentList[index]
    const {userInfo,isExtend} = this.data 
    const currentTime = db.serverDate();
    replyContent.push({
      reply,time,userInfo,currentTime
    }
    )
    db.collection('comment').doc(_id).update({
      data:{
        replyContent,
        isExtend 
      },
      success:(res) =>{
        wx.showToast({
          title:'回复成功'
        })
        this.onLoad()
      },
      fail:(res) =>{
        wx.showToast({
          icon:'none',
          title:'回复失败'
        })
      }, 
    })
    
  },
  //点赞
  like(e){
    const {item} = e.currentTarget.dataset;
    const {_id} = item;
    db.collection('comment').doc(_id).update({
      data:{
        isLike:true
      },
      success:(res) => {
        this.onLoad()
      }
    })
  },
    // 输入内容
    bindinput(e){
      this.setData({
        content:e.detail.value,
      })
    },
    sendOut(){
      wx.showLoading({
        title:'发布中~~'
      })
      const {content,userInfo,isLike,replyContent}=this.data //使用解构 
      db.collection('comment').add({
      data:{
        lookerID:'', 
        userInfo,
        time:getTimeNow(),
        isLike,
        replyContent,
        currentTime:db.serverDate(),
        info:{
          content,
        }
        },
        success:(res) =>{
          wx.showToast({
            title:'发布成功'
          })
          this.onLoad()
        },
        fail:(res) =>{
          wx.showToast({
            icon:'none',
            title:'发布失败'
          })
        },     
      })
      wx.hideLoading();    
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const lookerID = wx.getStorageSync('openid')
    const userInfo = wx.getStorageSync('userInfo')
    db.collection('comment').orderBy('currentTime','desc').get({
      success:(res) => {
        const { data } = res;
        this.setData({
          commentList:data,
        })    
      },
      fail:(res) => {
        showToast({
          icon:'none',
          title:'服务器异常'
        })
      }
    })
    this.setData({
      userInfo,
      lookerID,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () { 
    let {commentList} = this.data
    db.collection('comment').orderBy('currentTime','desc').skip(commentList.length).get({
      success:(res) => {
        if(res.data.length){
         this.setData({
          commentList,
        }) 
        }
        else{
          wx.showToast({
            icon:'none',
            title:'无更多信息'
          })
        }
        wx.hideLoading();
      },
      fail:(error) => {
        wx.showToast({
          icon:'none',
          title:'服务器出错',
        })
        wx.hideLoading();
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
