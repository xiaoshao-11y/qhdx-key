// pages/new/new.js
Page({
  onLoad: function (options) {
  this.setData({id:options.id,img:options.img,money:options.money,valuea:options.valuea,valueb:options.valueb,valuec:options.valuec,date:options.date,phone:options.phone,})
  },
  })