// pages/class/C1.js
const db=wx.cloud.database()
const caijingCollection=db.collection('caijing')
Page({

  /**
   * 页面的初始数据
   */
  data: {
  list1:' ',
  list:' ',
  ida:' '
  },
  getclass:function(res){
    const _ = db.command
    let that =this 
    db.collection('caijing').where({
      state:false
    })
    .get({
            success: function(res) {
              // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
              that.setData({
                  list:res.data,
                  ida:res.data[0]._id
              })
              console.log(res.data)
            }
          })
  },
  getstate:function(event){
    const _ = db.command
    let that =this 
    wx.showModal({
      title: '提示',
      content: '是否确认借用',
      success (ev) {
        if (ev.confirm) {
          console.log('用户点击确定')
          db.collection('caijing').where({
            state:false
          })
          .get({
                  success: function(res) {
                    // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
                    that.setData({
                        list:res.data,
                    })
                    caijingCollection.doc(res.data[0]._id).update({
                      data:{
                          state:true
                      },
                      success: function(e) {
                        
                        console.log('更改成功',e)
                        this.setData({
                          list1: list
                        })
                      }
                    })
      
                  }
                })
        } else if (ev.cancel) {
          console.log('用户点击取消')
        }
      }
    })   
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})