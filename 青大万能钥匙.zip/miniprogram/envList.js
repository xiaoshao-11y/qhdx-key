const envList = [{"envId":"mjy-8g65hi37657f862d","alias":"mjy"}]
const isMac = false
module.exports = {
    envList,
    isMac
}