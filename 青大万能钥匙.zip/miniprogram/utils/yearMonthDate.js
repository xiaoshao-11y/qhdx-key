export const getTimeYMD = () => {
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
      dataTime = `${yy}-${mm}-${dd}`;
      return dataTime
  }